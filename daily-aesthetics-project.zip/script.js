const filters = document.querySelectorAll(".filter");
const cards = document.querySelectorAll(".card");
const emptyMessage = document.querySelector(".empty-message");

filters.forEach((button) => {
  button.addEventListener("click", () => {
    const selected = button.dataset.filter;
    let visibleCount = 0;

    filters.forEach((item) => item.classList.toggle("active", item === button));

    cards.forEach((card) => {
      const show = selected === "all" || card.dataset.category === selected;
      card.hidden = !show;
      if (show) visibleCount++;
    });

    emptyMessage.hidden = visibleCount !== 0;
  });
});
