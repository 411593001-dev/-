# 日常美感圖鑑

以日常攝影、色彩靈感與點線面構成為主題的設計收藏網站。

## 本機預覽
直接用瀏覽器開啟 `index.html`。

## GitHub Pages
將整個資料夾內容推送到 GitHub Repository，進入 **Settings → Pages**，選擇 `Deploy from a branch`、`main` 與 `/(root)`，儲存後即可取得網站網址。

專案開發規則請見 [AGENTS.md](AGENTS.md)。
